<?php

namespace Mini\Cms\Entities;


use Mini\Cms\Modules\Content\Node\NodeBase;

class Node extends NodeBase
{
}