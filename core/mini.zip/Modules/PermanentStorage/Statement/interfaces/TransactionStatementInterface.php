<?php

namespace Mini\Cms\Modules\PermanentStorage\Statement\interfaces;

interface TransactionStatementInterface extends InsertionInterface, UpdateInterface, DeleteInterface
{
}