<?php

namespace Mini\Cms\Modules\Content\Tait;

class ConfigFileAlreadyExistException extends \Exception
{


}