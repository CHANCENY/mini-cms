<?php

namespace Mini\Cms\Modules\Content\Field;

class FieldNotFoundException
{

}