<?php

namespace Mini\Cms\Modules\Messenger;

class Messenger extends MessengerBuilder
{
    public function __construct()
    {
        parent::__construct();
    }
}