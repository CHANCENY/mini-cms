<?php

namespace Mini\Cms\Modules\Media\Videos;

class Streaming
{
    public function __construct(string $path)
    {
    }
}