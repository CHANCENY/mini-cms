<?php

namespace Mini\Cms\Services;

class ServiceProvideClassNotFound extends \Exception
{

}