<?php

namespace Mini\Cms\Services;

interface ServiceInterface
{
    public static function create(string $service_name);
}