<?php

namespace Mini\Cms\Controller;

class ControllerHandlerNotFoundException extends \Exception
{
}