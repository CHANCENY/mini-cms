<?php

namespace Mini\Cms\Controller;

class ControllerMissingException extends \Exception
{
}